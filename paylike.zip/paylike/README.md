# Ubercart plugin for Paylike [![Build Status](https://travis-ci.org/paylike/plugin-ubercart-7.x.svg?branch=master)](https://travis-ci.org/paylike/plugin-ubercart-7.x)

This plugin is *not* developed or maintained by Paylike but kindly made
available by a user.

Released under the GPL V3 license: https://opensource.org/licenses/GPL-3.0

## Supported Ubercart versions

[![Last succesfull test](https://log.derikon.ro/api/v1/log/read?tag=ubercart7&view=svg&label=Ubercart&key=ecommerce&background=e09e03)](https://log.derikon.ro/api/v1/log/read?tag=ubercart7&view=html)

*The plugin has been tested with most versions of Ubercart at every iteration. We recommend using the latest version of Ubercart, but if that is not possible for some reason, test the plugin with your Ubercart version and it would probably function properly.*

## Installation

Once you have installed Ubercart on your Drupal setup, follow these simple steps:
1. Signup at [paylike.io](https://paylike.io) (it’s free)
1. Create a live account
1. Create an app key for your Drupal website
1. Upload the ```paylike.zip``` trough the Drupal Admin (You can also find the latest release at https://www.drupal.org/project/uc_paylike)
1. Download and install the Paylike PHP Library version 1.0.4 or newer
       from https://github.com/paylike/php-api/releases. The recommended technique is
       to use the command:

       `drush ldl paylike`
    If you don't use `drush ldl paylike`, download and install the Paylike library in
       `sites/all/libraries/paylike` such that the path to `composer.json`
       is `sites/all/libraries/paylike/composer.json`. YOU MUST CLEAR THE CACHE AFTER
       CHANGING THE PAYLIKE PHP LIBRARY. The Libraries module caches its memory of
       libraries like the Paylike Library.
1. Activate the plugin through the 'Modules' screen in Drupal.
1.  Visit your Ubercart Store Administration page, Configuration
       section, and enable the gateway under the Payment Gateways.
       (admin/store/settings/payment/edit/gateways)
1. Select the default credit transaction type. This ˘module supports immediate
       or delayed capture modes. Immediate capture will be done when users confirm
       their orders. In delayed mode administrator should capture the money manually from
       orders administration page (admin/store/orders/view). Select an order and click
       "Process card" button in Payment block on the top. Check "PRIOR AUTHORIZATIONS"
       block to manually capture a needed amount of money.
1. Insert Paylike API keys, from https://app.paylike.io
       (admin/store/settings/payment/method/credit)
1. The uc_credit setting "Validate credit card numbers at checkout" must be
    disabled on `admin/store/settings/payment/method/credit` - uc_credit never sees
    the credit card number, so cannot properly validate it (and we don't want it to
    ever know the credit card number.)

## Updating settings

Under the Paylike payment method settings, you can:
 * Update the payment method text in the payment gateways list
 * Update the payment method description in the payment gateways list
 * Update the title that shows up in the payment popup
 * Add test/live keys
 * Set payment mode (test/live)
 * Change the capture type (Instant/Delayed)

 ## How to capture/refund/void

You can do capture/refund/void to an order using the Payment box in the order View Tab by press `Process card` button.
The amount for partial capture, refund or void can be specified in `Charge Amount` input field.

 1. Capture
 * In Instant mode, the orders are captured automatically.
 * In delayed mode you can capture an order select authorized transaction and then click `Capture amount to this authorization` button.
 2. Refund
   * To refund an order select authorized transaction and then click `Refund` button.
 3. Void
   * To void an order select authorized transaction and then click `Void authorization` button.

## Available features

1. Capture
   * Ubercart store admin panel: full/partial capture
   * Paylike admin panel: full/partial capture
2. Refund
   * Ubercart store admin panel: full/partial refund
   * Paylike admin panel: full/partial refund
3. Void
   * Ubercart store admin panel: full/partial void
   * Paylike admin panel: full/partial void